/*Program wczytuje tylko jedna liczbe n - dane do sortowania to n losowo wygenerowanych liczb*/

#include <cstdio>
#include <cstdlib>
#include <ctime>

int right(int i) { return i*2+2; }
int left(int i) { return i*2+1; }

void _swap(int *T, int i, int j){
    int temp = T[i];
    T[i] = T[j];
    T[j] = temp;
}

void maxHeapify(int *T, int &heapSize, int i){
    int largest;
    int l=left(i), r=right(i);
    if((l < heapSize) && (T[l] > T[i]))
        largest = l;
    else largest = i;
    if((r < heapSize) && (T[r] > T[largest]))
        largest = r;
    if(largest != i){
        _swap(T, i, largest);
        maxHeapify(T, heapSize, largest);
    }
}

void heapSort(int *T, int &n){
    int i;
    int heapSize = n;
    for(i = (n-1)/2; i >= 0; i--)
        maxHeapify(T, heapSize, i);

    for(i = n-1; i >= 1; i--){
        _swap(T, 0, i);
        heapSize--;
        maxHeapify(T, heapSize, 0);
    }
}

int main(void){
    int n, i, *T;
    scanf("%d",&n);
    T = new int[n];

    srand(time(NULL));
    for(i=0;i<n;i++)
        T[i] = rand()%1000;

    heapSort(T, n);
    for(i=0;i<n;i++)
        printf("%5d ",T[i]);
    delete T;
    return 0;
}
